public class App {
    public static void main(String[] args) throws Exception {
       LinkedBinaryTree<Character> bintree = new LinkedBinaryTree<>();
       bintree.addRoot('-').print();
       bintree.addLeft(null, null);
    }
}
