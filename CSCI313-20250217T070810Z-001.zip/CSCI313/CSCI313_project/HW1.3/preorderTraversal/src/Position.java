public interface Position<E> {
     
     //Returns the element stored at this position.
     
   //  @returnthestoredelement
     //@throwsIllegalStateExceptionifpositionnolongervalid
     //
    E getElement() throws IllegalStateException;
    void print();
}
   