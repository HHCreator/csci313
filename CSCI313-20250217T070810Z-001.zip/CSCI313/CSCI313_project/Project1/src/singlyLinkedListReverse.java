import java.util.*;

public class singlyLinkedListReverse {
    public static void main(String[] args) throws Exception {
        SinglyLinkedList<Integer> nodelist = new SinglyLinkedList<>();
        Scanner userinputScanner = new Scanner(System.in);
        int size=0;
        System.out.println("enter the number of nodes");
        size = userinputScanner.nextInt();
        for(int i =0;i<size;i++){
            System.out.println("enter the value of nodes");
            int value = userinputScanner.nextInt();//get the input value for the node
            nodelist.addFirst(value);//add to the list
            //add to infront, so will be reverse order
        }
        userinputScanner.close();
        nodelist.print();//print
    }
}
