import java.util.Scanner;
public class App {
    public static String reverseString(String s){
        if(s.length()==0){
            return "";
        }else{ char c =s.charAt(0);
            return reverseString(s.substring(1))+c;
        }
       
    }
    public static void main(String[] args) throws Exception {
        Scanner userinput = new Scanner(System.in);
        System.out.println("enter a string");
        String s = userinput.nextLine();
        System.out.println(reverseString(s));
        userinput.close();
    }
}
