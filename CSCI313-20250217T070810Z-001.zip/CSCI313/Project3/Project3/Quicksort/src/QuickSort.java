import java.util.ArrayList;
import java.util.Comparator;

import java.util.Random;

public class QuickSort {
    /** Quick-sort contents of a queue. */

public static <K> void quickSortD(ArrayList<K> S, Comparator<K> comp) {

    int n = S.size();
    if (n < 2) return;
    // queue is trivially sorted
    // divide
    K pivot =  S.get(0); // using first as arbitrary pivot
    
    ArrayList<K> L = new ArrayList<>();
    ArrayList<K> E = new ArrayList<>();
    ArrayList<K> G = new ArrayList<>();
    
    while (!S.isEmpty()) {  // divide original into L, E, and G
        K element = S.remove(0);
        int c = comp.compare(element, pivot);
        if (c < 0) // element is less than pivot
            L.add(element); 
        else if (c == 0)    // element is equal to pivot
            E.add(element);
        else  // element is greater than pivot
            G.add(element);
    }
    // conquer
    quickSortD(L, comp);    // sort elements less than pivot
    quickSortD(G, comp);   // sort elements greater than pivot
    // concatenate results
    while (!L.isEmpty())
        S.add(L.remove(0));
    while (!E.isEmpty())
        S.add(E.remove(0));
    while (!G.isEmpty())
        S.add(G.remove(0));
}



public static <K> void quickSortR(ArrayList<K> S, Comparator<K> comp) {
    int n = S.size();
    if (n < 2) return;
    // queue is trivially sorted
    // divide
    Random rand = new Random();
    int r = rand.nextInt(S.size());
    K pivot =  S.get(r); // using first as arbitrary pivot
    ArrayList<K> L = new ArrayList<>();
    ArrayList<K> E = new ArrayList<>();
    ArrayList<K> G = new ArrayList<>();
    
    while (!S.isEmpty()) {  // divide original into L, E, and G
        K element = S.remove(0);
        int c = comp.compare(element, pivot);
        if (c < 0) // element is less than pivot
            L.add(element); 
        else if (c == 0)    // element is equal to pivot
            E.add(element);
        else  // element is greater than pivot
            G.add(element);
    }
    // conquer
    quickSortR(L, comp);    // sort elements less than pivot
    quickSortR(G, comp);   // sort elements greater than pivot
    // concatenate results
    while (!L.isEmpty())
        S.add(L.remove(0));
    while (!E.isEmpty())
        S.add(E.remove(0));
    while (!G.isEmpty())
        S.add(G.remove(0));
}



    public static void main(String[] args) {
        Random randonN = new Random();
        ArrayList<Integer> myList= new ArrayList<>();
        DefaultComparator<Integer> mycomp = new DefaultComparator<>();
        /* 
        myList.add(3);
        myList.add(6);
        myList.add(8);
        myList.add(10);
        myList.add(1);
        myList.add(2);
        myList.add(1);
*/
        for(int i =1 ;i<30000;i++){
            int n = randonN.nextInt(i);
            myList.add(n);
        }
        //System.out.println("Original list: " + myList.toString() );
        ArrayList<Integer> myList2= (ArrayList<Integer>) myList.clone();
        long time0= System.currentTimeMillis();

        // Deterministic QuickSort
        quickSortD(myList,mycomp);
        //System.out.println("Deterministic QuickSort: " + myList.toString() );
        long time1= System.currentTimeMillis();
        System.out.println("Deterministic QuickSort use " + (time1 - time0) +" milliseconds"); 
        
        // Randomized QuickSort
        quickSortR(myList2, mycomp);
        //System.out.println("Randomized QuickSortR: " + myList2.toString());
        long time2= System.currentTimeMillis();
        System.out.println("Randomized QuickSort use " + (time2 -time1) +" milliseconds");
    }
}

