import java.util.LinkedList;
import java.util.Queue;

class TreeNode<K, V> {
    K key;
    V value;
    TreeNode<K, V> left, right;

    TreeNode(K key, V value) {
        this.key = key;
        this.value = value;
        this.left = this.right = null;
    }
}

class BST<K extends Comparable<K>, V> {
    private TreeNode<K, V> root;
    BST(){
        root = null;
    }

    public void removeSubMap(K k1, K k2) {
        root = removeRange(root, k1, k2);
    }

    private TreeNode<K, V> removeRange(TreeNode<K, V> node, K k1, K k2) {
        if (node == null) return null;

        // Recursively check subtrees
        node.left = removeRange(node.left, k1, k2);
        node.right = removeRange(node.right, k1, k2);

        // Remove node if it lies in the range
        if (node.key.compareTo(k1) >= 0 && node.key.compareTo(k2) <= 0) {
            if (node.left == null) return node.right;
            if (node.right == null) return node.left;

            // Replace with minimum node from the right subtree
            TreeNode<K, V> minNode = getMin(node.right);
            node.key = minNode.key;
            node.value = minNode.value;
            node.right = deleteMin(node.right);
        }

        return node;
    }

    private TreeNode<K, V> getMin(TreeNode<K, V> node) {
        while (node.left != null) node = node.left;
        return node;
    }

    private TreeNode<K, V> deleteMin(TreeNode<K, V> node) {
        if (node.left == null) return node.right;
        node.left = deleteMin(node.left);
        return node;
    }
    public void add(K key, V value){
        TreeNode<K,V> node = new TreeNode(key, value);
        if(root == null){
            root = node;
        }else{
            TreeNode<K,V> temp = root;
            while(temp != null ){
                if(node.key.compareTo(temp.key)<0 && temp.left != null){
                    temp = temp.left;
                }
                else if(node.key.compareTo(temp.key)>=0 && temp.right != null){
                    temp = temp.right;
                }

                //move postion

                if(node.key.compareTo(temp.key)<0 && temp.left == null){
                    temp.left = node;
                    break;
                }
               else if(node.key.compareTo(temp.key)>=0 && temp.right == null){
                    temp.right = node;
                    break;
                }
                //found, end loop

            }
        }
    }
    public void printBreadthFirst() {
        if (root == null) {
            System.out.println("Tree is empty");
            return;
        }

        Queue<TreeNode<K,V>> queue = new LinkedList<>();
        queue.add(root);

        System.out.print("Breadth-First Traversal: ");
        while (!queue.isEmpty()) {
            TreeNode<K,V> current = queue.poll();
            System.out.print(current.key + " ");

            // Add left and right children to the queue
            if (current.left != null) {
                queue.add(current.left);
                
            }
            if (current.right != null) {
                queue.add(current.right);
                
            }
            
        }
        System.out.println();
    }



}



public class App {
    public static void main(String[] args) throws Exception {
        BST<Integer,Integer>  binarySearchTree= new BST(); 
        binarySearchTree.add(10,666);
        binarySearchTree.add(5,666);
        binarySearchTree.add(15,666);
        binarySearchTree.add(3,666);
        binarySearchTree.add(7,666);
        binarySearchTree.add(13,666);
        binarySearchTree.add(18,666);
        binarySearchTree.printBreadthFirst();
        binarySearchTree.removeSubMap(0, 10);
        binarySearchTree.printBreadthFirst();


    }
}