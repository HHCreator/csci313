## Descreption
This program implements a method removeSubMap(k1, k2) to  delete all nodes whose keys lie within a specific range [k1, k2] in a Binary Search Tree (BST). 
//k1 must be the smaller one
This method use recursive and linkedlist based implementation to achieve the goal in the worst cast O(s+h)



## Example Input/Output
in the app class main method have the test code. 
it insert the node into BST {10, 5, 15, 3, 7, 13, 18} and remove from  the node who has key = 0 to key = 10
and there is a print method print this tree in  Breadth-First Traversal
Input: {10, 5, 15, 3, 7, 13, 18}
Output before remove : 10 5 15 3 7 13 18 
output after remove :  15 13 18
