## Descrepition
This program reimplements an AVL Tree to store the balance factor at each node instead of subtree heights. The balance factor is defined as:
    balanceFactor=height(left)−height(right)




## Example Input/Output
in the app class main method have the test code. 
it insert the node into BST {10,20,30,40,50,60,70}
and there is a print method print this tree in  Breadth-First Traversal
Input:  {10,20,30,40,50,60,70}
Output before remove : 40 20 60 10 30 50 70


