import java.util.LinkedList;
import java.util.Queue;

class AVLNode<K, V> {
    K key;
    V value;
    int balanceFactor; // balanceFactor = leftHeight - rightHeight
    AVLNode<K, V> left, right;

    AVLNode(K key, V value) {
        this.key = key;
        this.value = value;
        this.balanceFactor = 0;
    }
}

class AVLBalancedTree<K extends Comparable<K>, V> {
    private AVLNode<K, V> root;

    public void add(K key, V value) {
        root = insert(root, key, value);
    }

    private AVLNode<K, V> insert(AVLNode<K, V> node, K key, V value) {
        if (node == null) return new AVLNode<>(key, value);

        // Recursive insert
        if (key.compareTo(node.key) < 0) {
            node.left = insert(node.left, key, value);
        } else if (key.compareTo(node.key) > 0) {
            node.right = insert(node.right, key, value);
        } else {
            node.value = value; // Key already exists, update value
        }

        // Update balance factor
        node.balanceFactor = getHeight(node.left) - getHeight(node.right);

        // Perform rotations if necessary
        return balance(node);
    }

    private AVLNode<K, V> balance(AVLNode<K, V> node) {
        // Left heavy
        if (node.balanceFactor > 1) {
            if (node.left.balanceFactor < 0) node.left = rotateLeft(node.left);
            return rotateRight(node);
        }
        // Right heavy
        if (node.balanceFactor < -1) {
            if (node.right.balanceFactor > 0) node.right = rotateRight(node.right);
            return rotateLeft(node);
        }
        return node;
    }

    private int getHeight(AVLNode<K, V> node) {
        if (node == null) return 0;
        return Math.max(getHeight(node.left), getHeight(node.right)) + 1;
    }

    private AVLNode<K, V> rotateLeft(AVLNode<K, V> node) {
        AVLNode<K, V> newRoot = node.right;
        node.right = newRoot.left;
        newRoot.left = node;

        // Update balance factors
        node.balanceFactor = getHeight(node.left) - getHeight(node.right);
        newRoot.balanceFactor = getHeight(newRoot.left) - getHeight(newRoot.right);

        return newRoot;
    }

    private AVLNode<K, V> rotateRight(AVLNode<K, V> node) {
        AVLNode<K, V> newRoot = node.left;
        node.left = newRoot.right;
        newRoot.right = node;

        // Update balance factors
        node.balanceFactor = getHeight(node.left) - getHeight(node.right);
        newRoot.balanceFactor = getHeight(newRoot.left) - getHeight(newRoot.right);

        return newRoot;
    }

    public void printBreadthFirst() {
        if (root == null) {
            System.out.println("Tree is empty");
            return;
        }

        Queue<AVLNode<K,V>> queue = new LinkedList<>();
        queue.add(root);

        System.out.print("Breadth-First Traversal: ");
        while (!queue.isEmpty()) {
            AVLNode<K,V> current = queue.poll();
            System.out.print(current.key + " ");

            // Add left and right children to the queue
            if (current.left != null) {
                queue.add(current.left);
                
                
            }
            if (current.right != null) {
                queue.add(current.right);
                
                
            }
            
        }
        System.out.println();
    }

    public AVLBalancedTree(){
        root= null;
    }


}



public class App {
    public static void main(String[] args) throws Exception {
        AVLBalancedTree<Integer, Integer>  ATree = new AVLBalancedTree<>();
        ATree.add(10, 666);
        ATree.add(20, 666);
        ATree.add(30, 666);
        ATree.add(40, 666);
        ATree.add(50, 666);
        ATree.add(60, 666);
        ATree.add(70, 666);
        ATree.printBreadthFirst();
    }
}
