import java.util.Random;
import java.util.Stack;


public class skipList <T> {
    private static final float skip_p = 0.5f;
    private static final int MAX_LEVEL = 16;
    private SkipNode head;
    private int levelCount ;
    private Random r ;

//nest class
    private class SkipNode<T>{
        protected int key;
        protected T value;
        protected SkipNode next= null;
        protected SkipNode below= null;

        public SkipNode (int key, T value){
                this.key = key;
                this.value = value;
        }
      
    }
    //nest class end
    public skipList (){//constructor , set up the base stuffs
        r = new Random();
        head = new SkipNode(Integer.MIN_VALUE, null);
        levelCount = 0;
        
   
    }
    public SkipNode skipSearch(int key) {
        /*use loop to go through the whole list

         * the list is sorted from small to greatest by key, so meanwhile it has 4 cases:
         * 1: find, so just return
         * 2: no find, but reach the sential, so go below
         * 3, no find , but the next has greater key, so go below
         * 4, no find, but the next has smaller key, so keep go next
         */



        SkipNode p = head;
        while (p!=null) {
            if(p.key==key)// find
            {
                while(p.below != null){
                    p = p.below;
                }
                return  p;
            }
            else if(p.next==null)//reach the sential, go below
            {
                p=p.below;
            }
            else if(p.next.key>key)// reach the greater, go below
            {
                p=p.below;
            }
            else //keep go next, if next is smaller and exist
            {
                p=p.next;
            }
        }

        return null;

    };

    public void skipRemove(int key)//loop :find the node by key, and delete, then go below, then delete
    {//basiclly the same as the search method, but change the process when search,need deletion when find
        SkipNode temp=head;
        while (temp!=null) {
            if (temp.next == null) {//reach sential, go below
                temp=temp.below;
            }
            else if(temp.next.key==key)//find it
            {
                temp.next=temp.next.next;//deletion
                temp=temp.below;//and go below
            }
            else if(temp.next.key>key)// next is greater, go below
            {
                temp=temp.below;
            }
            else { //next is smaller, so go next
                temp=temp.next;
            }
        }
    }
     public void skipInsert(int k, T v)
    {
        /*when insert, it has the different  to the remove,in deletion we don't need to know what is the level
         * we just search from top to bottom then remove the node when find,
         *  but insertion we need promote the node from bottom to the top, 
         * so we need to what is the current level to make sure we are insert from the bottom
         * so we use a stack to store the position we can insert, because we add position to stack is from top to bottom becasue the search algor
         * then the pop will be the bottom list, so we use .pop from stack to get the position, then search the
         * position and insert, if level is newer, then repeat.
        */
        SkipNode findNode=skipSearch(k);//just incase if this key is already exist
        
        if(findNode!=null)//if exist
        {
            findNode.value=v;// change the value of the node
            return;
        }

        Stack<SkipNode>stack=new Stack<SkipNode>();//use stack to store all the position need to insert the node
        SkipNode temp=head;//point to the head, start from it, 
        while (temp!=null) {//search start, search all the position we can insert
            if(temp.next==null)// reach the sential, go below 
            {
                stack.add(temp);//store the position to the stack, then do below
                temp=temp.below;
            }
            else if(temp.next.key>k)//next key is greater, go down
            {
                stack.add(temp);//store the position
                temp=temp.below;
            }
            else //go next
            {
                temp=temp.next;
            }
        }

        int level=1;//current level, start from level 1
        SkipNode belowNode=null;//the below node, make sure the promotion node can go below, initial is null
        while (!stack.isEmpty()) {
            // start to insert
            /* two case in horizental insertion, reach the sential or not
             * 1: reach sential, so insert to the next of the position, no need to change the next of node
             * 2: reach the greater key, so insert between them , need to change the next of node to the next of temp.
             */
            temp=stack.pop();//get the position  from the .pop method,//creat the node to insert
            SkipNode node = new SkipNode<T>(k, v);// create the node
            node.below=belowNode;// assign the below
            belowNode=node;//update the below for the promotion if need
            if(temp.next==null) {// if the position is next to the sential, then insert it
                temp.next=node;
            }
            
            else {// the position is next to a node, insert between
                node.next=temp.next;
                temp.next=node;
            }
            //promote now
            if(level>MAX_LEVEL)//we only set 16 sub list, no more
                break;
            double num=r.nextDouble();//[0-1] get a random number
            if(num>0.5)// if the number is greater than 0.5, so no promote, just break the loop
                break;
            level++;//if <=0.5, go above,
            if(level>levelCount)//speaical case:  we promote a node that has new newest level, or we just creat the first node
            {/* that will lead to a new head node, a new levelcount */
                levelCount=level;//new levelcount
                //new head node, highest list
                SkipNode newHeadNode=new SkipNode(Integer.MIN_VALUE, null);
                newHeadNode.below=head;
                head=newHeadNode;//change head
                stack.add(head);// and add this new head to the stack for to connect to the node
            }
        }

    }

    public void printAll() {//print everything
        SkipNode p = head;
        SkipNode last=p;// the last row, contain all entry
        while(last.below != null){
            last = last.below;
        }

        while (p!=null) {
            SkipNode enumNode=p.next;// the current row 
            SkipNode enumLast=last.next;// the last row
            System.out.printf("%-8s","head->");// format
            while (enumLast!=null&&enumNode!=null) {//only stop when both reach the sential
                if(enumLast.key==enumNode.key)// when last row find the current row's key, print the key and move together
                {
                    System.out.printf("%-5s",enumLast.key+"->");
                    enumLast=enumLast.next;
                    enumNode=enumNode.next;
                }
                else{
                    enumLast=enumLast.next;//last row cross the entry between  the current row's entry
                    System.out.printf("%-5s","");//print nothing, keep format
                }

            }
            p=p.below;//go to next row
           
            System.out.println();
        }
    }




    public static void main(String[] args) throws Exception {
        skipList<Integer>list=new skipList<Integer>();
        for(int i=1;i<20;i++)
        {
            list.skipInsert(i,666);
        }
        System.out.println(list.skipSearch(15).value);
        list.printAll();
        list.skipRemove(15);
        list.skipRemove(4);
        list.skipRemove(8);
        list.skipInsert(15, 30);
        list.printAll();
        System.out.println(list.skipSearch(15).value);
    }
}
